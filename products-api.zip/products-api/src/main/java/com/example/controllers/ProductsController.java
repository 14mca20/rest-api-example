package com.example.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Products;
import com.example.repository.ProductsRepository;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
public class ProductsController {

	@Autowired
	ProductsRepository productsRepository;

	@GetMapping("/products/{productId}")
	public Products getProducts(@PathVariable String productId) {

		Optional<Products> proOptional = productsRepository.findById(Long.parseLong(productId));
		if (proOptional.isPresent())
			return proOptional.get();
		return null;
	}

	@PostMapping("/products/create")
	public ResponseEntity<Products> createProduct(@RequestBody Products products) {
		productsRepository.save(products);
		return new ResponseEntity<Products>(products, HttpStatus.CREATED);
	}

	@PutMapping("/products/update/{productId}")
	public ResponseEntity<Products> updateProduct(@PathVariable String productId, @RequestBody Products products) {
		Optional<Products> proOptional = productsRepository.findById(Long.parseLong(productId));
		if (proOptional.isPresent()) {
			Products newProduct = proOptional.get();
			newProduct.setPrice(products.getPrice());
			newProduct.setProductName(products.getProductName());
			productsRepository.save(newProduct);
			return new ResponseEntity<Products>(newProduct, HttpStatus.ACCEPTED);
		}
		return new ResponseEntity<Products>(products, HttpStatus.INSUFFICIENT_STORAGE);
	}

	@DeleteMapping("/products/{productId}")
	public ResponseEntity<Products> deleteProducts(@PathVariable String productId) {
		Optional<Products> proOptional = productsRepository.findById(Long.parseLong(productId));
		if (proOptional.isPresent()) {
			productsRepository.deleteById(Long.parseLong(productId));
			return new ResponseEntity<Products>(proOptional.get(), HttpStatus.OK);
		}
		return null;
	}
}
