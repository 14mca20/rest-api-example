package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Products;

public interface ProductsRepository extends JpaRepository<Products, Long> {
	List<Products> findByProductId(String productId);
}
